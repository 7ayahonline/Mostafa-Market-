# المصطفى — نسخة GitHub Pages كاملة

هذه الحزمة مصممة للرفع **مباشرة** إلى جذر مستودع `Mostafa-Market` على فرع `main`.

## أهم إصلاح
يجب أن يكون الملف `index.html` في جذر المستودع، وليس داخل مجلد `Mostafa-Market-FINAL` أو أي مجلد آخر.

## إعداد GitHub Pages
الطريقة الموصى بها:
1. ارفع محتويات الحزمة إلى `main`.
2. افتح Settings → Pages.
3. اختر **GitHub Actions** كمصدر النشر.
4. بعد نجاح الـworkflow افتح:
   https://7ayahonline.github.io/Mostafa-Market/

ويمكن بدلًا من ذلك اختيار Deploy from a branch → `main` → `/(root)`.

## محتويات الحزمة
- `index.html` الصفحة الرئيسية.
- `404.html` نسخة التطبيق لمعالجة المسارات غير الموجودة.
- `manifest.json` و`sw.js` وملفات الأيقونات لـPWA والكاش.
- `.nojekyll`.
- `.github/workflows/pages.yml` للنشر التلقائي.
- `robots.txt` و`sitemap.xml`.

## ملاحظة
المشروع Front-end. السلة والمفضلة والطلبات تعمل محليًا في المتصفح. الدفع وقاعدة البيانات والحسابات والمخزون المتزامن تحتاج Backend خارجي.
